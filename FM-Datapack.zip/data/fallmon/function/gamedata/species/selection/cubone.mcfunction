# UNUSED(?), WE ARE USING TEAM UPDATE INSTEAD

# Replace default with species name. Or team name in this case.
team join cubone @p

# data
# default stats
attribute @p minecraft:movement_speed base set 0.12
attribute @p minecraft:armor base set 2
attribute @p minecraft:max_health base set 20
attribute @p minecraft:attack_damage base set 2
attribute @p minecraft:attack_knockback base set 0

effect clear @p fire_resistance
effect clear @p jump_boost
effect clear @p water_breathing
effect clear @p haste

# at the end put the species name
title @p actionbar {"text": "You are playing as Cubone", "color": "#47FF47"}

# complete
effect give @p regeneration 2 255 true
# change these to what is updated stats, as for "You have chosen " put the species name there.
tellraw @p {"text": "You have chosen Cubone", "color" : "#47FF47", "bold": true}
tellraw @p {"text": "Speed: x1.2", "color" : "#47FF47"}
tellraw @p {"text": "Natural Armor: 2", "color" : "#47FF47"}
tellraw @p {"text": "HP: 20", "color" : "#47FF47"}
tellraw @p {"text": "DMG: x1", "color" : "#47FF47"}
tellraw @p {"text": "Knockback: None", "color" : "#47FF47"}
playsound choose.cubone master @a ~ ~ ~ 1000 1