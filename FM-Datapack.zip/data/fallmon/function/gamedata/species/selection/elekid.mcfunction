# UNUSED(?), WE ARE USING TEAM UPDATE INSTEAD

# Replace default with species name. Or team name in this case.
team join elekid @p

# data
# default stats
attribute @p minecraft:movement_speed base set 0.17
attribute @p minecraft:armor base set 0
attribute @p minecraft:max_health base set 14
attribute @p minecraft:attack_damage base set 6
attribute @p minecraft:attack_knockback base set 0

effect clear @p fire_resistance
effect clear @p jump_boost
effect clear @p water_breathing
effect clear @p haste

# at the end put the species name
title @p actionbar {"text": "You are playing as Elekid", "color": "#47FF47"}

# complete
effect give @p regeneration 2 255 true
# change these to what is updated stats, as for "You have chosen " put the species name there.
tellraw @p {"text": "You have chosen Elekid", "color" : "#47FF47", "bold": true}
tellraw @p {"text": "Speed: x1.7", "color" : "#47FF47"}
tellraw @p {"text": "Natural Armor: None", "color" : "#47FF47"}
tellraw @p {"text": "HP: 14", "color" : "#47FF47"}
tellraw @p {"text": "DMG: x3", "color" : "#47FF47"}
tellraw @p {"text": "Knockback: None", "color" : "#47FF47"}
playsound block.note_block.pling master @a ~ ~ ~ 1000 0